import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _90d51e98 = () => interopDefault(import('..\\pages\\acerca.vue' /* webpackChunkName: "pages/acerca" */))
const _3d96b928 = () => interopDefault(import('..\\pages\\centro_de_medios.vue' /* webpackChunkName: "pages/centro_de_medios" */))
const _02305356 = () => interopDefault(import('..\\pages\\contacto.vue' /* webpackChunkName: "pages/contacto" */))
const _816836b8 = () => interopDefault(import('..\\pages\\cursos\\index.vue' /* webpackChunkName: "pages/cursos/index" */))
const _3d3d0f98 = () => interopDefault(import('..\\pages\\emprendedores\\index.vue' /* webpackChunkName: "pages/emprendedores/index" */))
const _c2336a4a = () => interopDefault(import('..\\pages\\eventos\\index.vue' /* webpackChunkName: "pages/eventos/index" */))
const _1bda6f66 = () => interopDefault(import('..\\pages\\home.vue' /* webpackChunkName: "pages/home" */))
const _e2198cdc = () => interopDefault(import('..\\pages\\iniciar_sesion.vue' /* webpackChunkName: "pages/iniciar_sesion" */))
const _f7598966 = () => interopDefault(import('..\\pages\\noticias\\index.vue' /* webpackChunkName: "pages/noticias/index" */))
const _efa92a02 = () => interopDefault(import('..\\pages\\organizadores.vue' /* webpackChunkName: "pages/organizadores" */))
const _215a0063 = () => interopDefault(import('..\\pages\\programas\\index.vue' /* webpackChunkName: "pages/programas/index" */))
const _656c913a = () => interopDefault(import('..\\pages\\registro.vue' /* webpackChunkName: "pages/registro" */))
const _bf1ecf44 = () => interopDefault(import('..\\pages\\tematicas\\index.vue' /* webpackChunkName: "pages/tematicas/index" */))
const _1d1880c4 = () => interopDefault(import('..\\pages\\emprendedores\\testimonios.vue' /* webpackChunkName: "pages/emprendedores/testimonios" */))
const _07577710 = () => interopDefault(import('..\\pages\\nosotros\\directorio.vue' /* webpackChunkName: "pages/nosotros/directorio" */))
const _e9ee8d30 = () => interopDefault(import('..\\pages\\nosotros\\politica-de-calidad.vue' /* webpackChunkName: "pages/nosotros/politica-de-calidad" */))
const _603b362e = () => interopDefault(import('..\\pages\\nosotros\\quienes-somos.vue' /* webpackChunkName: "pages/nosotros/quienes-somos" */))
const _20f1d794 = () => interopDefault(import('..\\pages\\nosotros\\vision-y-mision.vue' /* webpackChunkName: "pages/nosotros/vision-y-mision" */))
const _0888cc66 = () => interopDefault(import('..\\pages\\servicios\\agente-operador-corfo.vue' /* webpackChunkName: "pages/servicios/agente-operador-corfo" */))
const _9aec1090 = () => interopDefault(import('..\\pages\\servicios\\agente-operador-sercotec.vue' /* webpackChunkName: "pages/servicios/agente-operador-sercotec" */))
const _350d5794 = () => interopDefault(import('..\\pages\\usuario\\nueva-password.vue' /* webpackChunkName: "pages/usuario/nueva-password" */))
const _1c2bac16 = () => interopDefault(import('..\\pages\\usuario\\recuperar-password.vue' /* webpackChunkName: "pages/usuario/recuperar-password" */))
const _1f366111 = () => interopDefault(import('..\\pages\\emprendedores\\emprendedor\\_id.vue' /* webpackChunkName: "pages/emprendedores/emprendedor/_id" */))
const _edda7fe8 = () => interopDefault(import('..\\pages\\cursos\\_id.vue' /* webpackChunkName: "pages/cursos/_id" */))
const _1dcd3c82 = () => interopDefault(import('..\\pages\\emprendedores\\_id\\index.vue' /* webpackChunkName: "pages/emprendedores/_id/index" */))
const _7e05931f = () => interopDefault(import('..\\pages\\eventos\\_id\\index.vue' /* webpackChunkName: "pages/eventos/_id/index" */))
const _4d4355d0 = () => interopDefault(import('..\\pages\\nosotros\\_page.vue' /* webpackChunkName: "pages/nosotros/_page" */))
const _5621acf5 = () => interopDefault(import('..\\pages\\noticias\\_id.vue' /* webpackChunkName: "pages/noticias/_id" */))
const _2f22bf8b = () => interopDefault(import('..\\pages\\programas\\_id.vue' /* webpackChunkName: "pages/programas/_id" */))
const _204cb5f8 = () => interopDefault(import('..\\pages\\servicios\\_page.vue' /* webpackChunkName: "pages/servicios/_page" */))
const _0ef78df8 = () => interopDefault(import('..\\pages\\usuario\\_perfil.vue' /* webpackChunkName: "pages/usuario/_perfil" */))
const _4bbf5c96 = () => interopDefault(import('..\\pages\\eventos\\_id\\inscripcion.vue' /* webpackChunkName: "pages/eventos/_id/inscripcion" */))
const _989e7e4a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/acerca",
    component: _90d51e98,
    name: "acerca"
  }, {
    path: "/centro_de_medios",
    component: _3d96b928,
    name: "centro_de_medios"
  }, {
    path: "/contacto",
    component: _02305356,
    name: "contacto"
  }, {
    path: "/cursos",
    component: _816836b8,
    name: "cursos"
  }, {
    path: "/emprendedores",
    component: _3d3d0f98,
    name: "emprendedores"
  }, {
    path: "/eventos",
    component: _c2336a4a,
    name: "eventos"
  }, {
    path: "/home",
    component: _1bda6f66,
    name: "home"
  }, {
    path: "/iniciar_sesion",
    component: _e2198cdc,
    name: "iniciar_sesion"
  }, {
    path: "/noticias",
    component: _f7598966,
    name: "noticias"
  }, {
    path: "/organizadores",
    component: _efa92a02,
    name: "organizadores"
  }, {
    path: "/programas",
    component: _215a0063,
    name: "programas"
  }, {
    path: "/registro",
    component: _656c913a,
    name: "registro"
  }, {
    path: "/tematicas",
    component: _bf1ecf44,
    name: "tematicas"
  }, {
    path: "/emprendedores/testimonios",
    component: _1d1880c4,
    name: "emprendedores-testimonios"
  }, {
    path: "/nosotros/directorio",
    component: _07577710,
    name: "nosotros-directorio"
  }, {
    path: "/nosotros/politica-de-calidad",
    component: _e9ee8d30,
    name: "nosotros-politica-de-calidad"
  }, {
    path: "/nosotros/quienes-somos",
    component: _603b362e,
    name: "nosotros-quienes-somos"
  }, {
    path: "/nosotros/vision-y-mision",
    component: _20f1d794,
    name: "nosotros-vision-y-mision"
  }, {
    path: "/servicios/agente-operador-corfo",
    component: _0888cc66,
    name: "servicios-agente-operador-corfo"
  }, {
    path: "/servicios/agente-operador-sercotec",
    component: _9aec1090,
    name: "servicios-agente-operador-sercotec"
  }, {
    path: "/usuario/nueva-password",
    component: _350d5794,
    name: "usuario-nueva-password"
  }, {
    path: "/usuario/recuperar-password",
    component: _1c2bac16,
    name: "usuario-recuperar-password"
  }, {
    path: "/emprendedores/emprendedor/:id?",
    component: _1f366111,
    name: "emprendedores-emprendedor-id"
  }, {
    path: "/cursos/:id",
    component: _edda7fe8,
    name: "cursos-id"
  }, {
    path: "/emprendedores/:id",
    component: _1dcd3c82,
    name: "emprendedores-id"
  }, {
    path: "/eventos/:id",
    component: _7e05931f,
    name: "eventos-id"
  }, {
    path: "/nosotros/:page?",
    component: _4d4355d0,
    name: "nosotros-page"
  }, {
    path: "/noticias/:id",
    component: _5621acf5,
    name: "noticias-id"
  }, {
    path: "/programas/:id",
    component: _2f22bf8b,
    name: "programas-id"
  }, {
    path: "/servicios/:page?",
    component: _204cb5f8,
    name: "servicios-page"
  }, {
    path: "/usuario/:perfil?",
    component: _0ef78df8,
    name: "usuario-perfil"
  }, {
    path: "/eventos/:id/inscripcion",
    component: _4bbf5c96,
    name: "eventos-id-inscripcion"
  }, {
    path: "/",
    component: _989e7e4a,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
