import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']

let store = {};

(function updateModules () {
  store = normalizeRoot(require('..\\store\\index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('..\\store\\contenidos\\actions.js'), 'contenidos/actions.js')
  resolveStoreModules(require('..\\store\\contenidos\\getters.js'), 'contenidos/getters.js')
  resolveStoreModules(require('..\\store\\contenidos\\mutations.js'), 'contenidos/mutations.js')
  resolveStoreModules(require('..\\store\\contenidos\\state.js'), 'contenidos/state.js')
  resolveStoreModules(require('..\\store\\eventos\\actions.js'), 'eventos/actions.js')
  resolveStoreModules(require('..\\store\\eventos\\getters.js'), 'eventos/getters.js')
  resolveStoreModules(require('..\\store\\eventos\\mutations.js'), 'eventos/mutations.js')
  resolveStoreModules(require('..\\store\\eventos\\state.js'), 'eventos/state.js')
  resolveStoreModules(require('..\\store\\formatos\\actions.js'), 'formatos/actions.js')
  resolveStoreModules(require('..\\store\\formatos\\getters.js'), 'formatos/getters.js')
  resolveStoreModules(require('..\\store\\formatos\\mutations.js'), 'formatos/mutations.js')
  resolveStoreModules(require('..\\store\\formatos\\state.js'), 'formatos/state.js')
  resolveStoreModules(require('..\\store\\noticias\\actions.js'), 'noticias/actions.js')
  resolveStoreModules(require('..\\store\\noticias\\getters.js'), 'noticias/getters.js')
  resolveStoreModules(require('..\\store\\noticias\\mutations.js'), 'noticias/mutations.js')
  resolveStoreModules(require('..\\store\\noticias\\state.js'), 'noticias/state.js')
  resolveStoreModules(require('..\\store\\organizaciones\\actions.js'), 'organizaciones/actions.js')
  resolveStoreModules(require('..\\store\\organizaciones\\getters.js'), 'organizaciones/getters.js')
  resolveStoreModules(require('..\\store\\organizaciones\\mutations.js'), 'organizaciones/mutations.js')
  resolveStoreModules(require('..\\store\\organizaciones\\state.js'), 'organizaciones/state.js')
  resolveStoreModules(require('..\\store\\organizadores\\actions.js'), 'organizadores/actions.js')
  resolveStoreModules(require('..\\store\\organizadores\\getters.js'), 'organizadores/getters.js')
  resolveStoreModules(require('..\\store\\organizadores\\mutations.js'), 'organizadores/mutations.js')
  resolveStoreModules(require('..\\store\\organizadores\\state.js'), 'organizadores/state.js')
  resolveStoreModules(require('..\\store\\programas\\actions.js'), 'programas/actions.js')
  resolveStoreModules(require('..\\store\\programas\\getters.js'), 'programas/getters.js')
  resolveStoreModules(require('..\\store\\programas\\mutations.js'), 'programas/mutations.js')
  resolveStoreModules(require('..\\store\\programas\\state.js'), 'programas/state.js')
  resolveStoreModules(require('..\\store\\session\\actions.js'), 'session/actions.js')
  resolveStoreModules(require('..\\store\\session\\getters.js'), 'session/getters.js')
  resolveStoreModules(require('..\\store\\session\\mutations.js'), 'session/mutations.js')
  resolveStoreModules(require('..\\store\\session\\state.js'), 'session/state.js')
  resolveStoreModules(require('..\\store\\ui\\actions.js'), 'ui/actions.js')
  resolveStoreModules(require('..\\store\\ui\\getters.js'), 'ui/getters.js')
  resolveStoreModules(require('..\\store\\ui\\mutations.js'), 'ui/mutations.js')
  resolveStoreModules(require('..\\store\\ui\\state.js'), 'ui/state.js')
  resolveStoreModules(require('..\\store\\paginas\\contacto\\actions.js'), 'paginas/contacto/actions.js')
  resolveStoreModules(require('..\\store\\paginas\\contacto\\getters.js'), 'paginas/contacto/getters.js')
  resolveStoreModules(require('..\\store\\paginas\\contacto\\mutations.js'), 'paginas/contacto/mutations.js')
  resolveStoreModules(require('..\\store\\paginas\\contacto\\state.js'), 'paginas/contacto/state.js')
  resolveStoreModules(require('..\\store\\paginas\\emprendedores\\actions.js'), 'paginas/emprendedores/actions.js')
  resolveStoreModules(require('..\\store\\paginas\\emprendedores\\getters.js'), 'paginas/emprendedores/getters.js')
  resolveStoreModules(require('..\\store\\paginas\\emprendedores\\mutations.js'), 'paginas/emprendedores/mutations.js')
  resolveStoreModules(require('..\\store\\paginas\\emprendedores\\state.js'), 'paginas/emprendedores/state.js')
  resolveStoreModules(require('..\\store\\paginas\\footer\\actions.js'), 'paginas/footer/actions.js')
  resolveStoreModules(require('..\\store\\paginas\\footer\\getters.js'), 'paginas/footer/getters.js')
  resolveStoreModules(require('..\\store\\paginas\\footer\\mutations.js'), 'paginas/footer/mutations.js')
  resolveStoreModules(require('..\\store\\paginas\\footer\\state.js'), 'paginas/footer/state.js')
  resolveStoreModules(require('..\\store\\paginas\\inicio\\actions.js'), 'paginas/inicio/actions.js')
  resolveStoreModules(require('..\\store\\paginas\\inicio\\getters.js'), 'paginas/inicio/getters.js')
  resolveStoreModules(require('..\\store\\paginas\\inicio\\mutations.js'), 'paginas/inicio/mutations.js')
  resolveStoreModules(require('..\\store\\paginas\\inicio\\state.js'), 'paginas/inicio/state.js')
  resolveStoreModules(require('..\\store\\paginas\\nosotros\\actions.js'), 'paginas/nosotros/actions.js')
  resolveStoreModules(require('..\\store\\paginas\\nosotros\\getters.js'), 'paginas/nosotros/getters.js')
  resolveStoreModules(require('..\\store\\paginas\\nosotros\\mutations.js'), 'paginas/nosotros/mutations.js')
  resolveStoreModules(require('..\\store\\paginas\\nosotros\\state.js'), 'paginas/nosotros/state.js')
  resolveStoreModules(require('..\\store\\paginas\\servicios\\actions.js'), 'paginas/servicios/actions.js')
  resolveStoreModules(require('..\\store\\paginas\\servicios\\getters.js'), 'paginas/servicios/getters.js')
  resolveStoreModules(require('..\\store\\paginas\\servicios\\mutations.js'), 'paginas/servicios/mutations.js')
  resolveStoreModules(require('..\\store\\paginas\\servicios\\state.js'), 'paginas/servicios/state.js')

  // If the environment supports hot reloading...
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function normalizeRoot (moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule (moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    console.warn(`'state' should be a method that returns an object in ${filePath}`)

    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function resolveStoreModules (moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs|ts)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const propertyStoreModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(propertyStoreModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeState (moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    console.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function getStoreModule (storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty (storeModule, moduleData, property) {
  if (!moduleData) {
    return
  }

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}
