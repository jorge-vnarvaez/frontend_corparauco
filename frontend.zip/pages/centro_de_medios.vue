<template>
  <inicio />
</template>

<script>
import Inicio from '../components/centro_de_medios/Inicio.vue'
export default {
  components: { Inicio },

}
</script>

<style>

</style>