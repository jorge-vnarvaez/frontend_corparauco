<template>
  <div>
    <h1>Cursos</h1>
    <cursos-list />
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>