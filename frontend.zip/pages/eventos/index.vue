<template>
  <div> 
    <eventos-list />
  </div>
</template>

<script>
import EventosList from '../../components/eventos/EventosList.vue';
export default {
  components: { EventosList },

};
</script>

<style>
</style>
