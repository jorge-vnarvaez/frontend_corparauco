export default {
    setContenidos(state, data) {
        state.contenidos = data;
    }
}