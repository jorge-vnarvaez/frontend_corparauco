export default () => ({
    namespaced: true,
    contenidos: [],
});