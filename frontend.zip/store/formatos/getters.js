export default {
    getFormatos(state) {
        return state.formatos;
    }
}