export default {
    setFormatos(state, data) {
        state.formatos = data;
    }
}