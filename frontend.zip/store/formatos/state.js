export default () => ({
    namespaced: true,
    formatos: []
});