export default {
    setNoticias(state, noticias) {
        state.noticias = noticias;
    }
}