export default {
    setOrganizaciones(state, data) {
        state.organizaciones = data;
    }
}