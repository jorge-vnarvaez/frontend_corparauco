export default {
    getOrganizadores(state) {
        return state.organizadores;
    }
}