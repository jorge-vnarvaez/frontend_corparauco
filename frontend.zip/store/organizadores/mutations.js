export default {
    setOrganizadores(state, organizadores) {
        state.organizadores = organizadores;
    },
}

