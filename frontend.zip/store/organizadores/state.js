export default () => ({
    namespaced: true,
    organizadores: []
});