export default () => ({
    pagina: {}
});