export default {
    getPaginaTestimonios(state) {
        return state.paginaTestimonios;
    },
    getPaginaEmprendedores(state) {
        return state.paginaEmprendedores;
    },
}