export default {
    setPagina(state, data) {

        const pagina = data.attributes;

        state.pagina = pagina;

    }
}