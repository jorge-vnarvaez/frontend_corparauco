export default {
    getPagina(state) {
        return state.pagina;
    },
    getAppLogo(state) {
        return state.app_logo;
    },
    getAppName(state) {
        return state.app_name;
    },
    getAppSubtitle(state) {
        return state.app_subtitle;
    }
}