export default () => ({
    app_logo: null,
    app_name: null,
    app_subtitle: null,
    pagina: {}
});