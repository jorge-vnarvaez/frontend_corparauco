export default () => ({
    paginas: [],
})