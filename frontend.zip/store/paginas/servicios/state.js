export default () => ({
    paginas: []
});