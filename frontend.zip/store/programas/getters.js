export default {
    getProgramas(state) {
        return state.programas;
    }
}