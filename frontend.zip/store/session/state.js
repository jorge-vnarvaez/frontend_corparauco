export default () => ({
    namespaced: true,
    is_logged: false,
    user: null,
    error: false,
    errorMsg: 'Credenciales invalidas',
})