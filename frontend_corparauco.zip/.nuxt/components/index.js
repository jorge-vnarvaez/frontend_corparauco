export const CentroDeMediosBarraOrganizadores = () => import('../..\\components\\centro_de_medios\\BarraOrganizadores.vue' /* webpackChunkName: "components/centro-de-medios-barra-organizadores" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosCursos = () => import('../..\\components\\centro_de_medios\\Cursos.vue' /* webpackChunkName: "components/centro-de-medios-cursos" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosCursosRecientes = () => import('../..\\components\\centro_de_medios\\CursosRecientes.vue' /* webpackChunkName: "components/centro-de-medios-cursos-recientes" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosCursosRecomendados = () => import('../..\\components\\centro_de_medios\\CursosRecomendados.vue' /* webpackChunkName: "components/centro-de-medios-cursos-recomendados" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosInicio = () => import('../..\\components\\centro_de_medios\\Inicio.vue' /* webpackChunkName: "components/centro-de-medios-inicio" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosNuevosCursos = () => import('../..\\components\\centro_de_medios\\NuevosCursos.vue' /* webpackChunkName: "components/centro-de-medios-nuevos-cursos" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosNuevosCursosComponent = () => import('../..\\components\\centro_de_medios\\NuevosCursosComponent.vue' /* webpackChunkName: "components/centro-de-medios-nuevos-cursos-component" */).then(c => wrapFunctional(c.default || c))
export const CentroDeMediosOrganizadoresRecomendados = () => import('../..\\components\\centro_de_medios\\OrganizadoresRecomendados.vue' /* webpackChunkName: "components/centro-de-medios-organizadores-recomendados" */).then(c => wrapFunctional(c.default || c))
export const EmprendedoresList = () => import('../..\\components\\emprendedores\\EmprendedoresList.vue' /* webpackChunkName: "components/emprendedores-list" */).then(c => wrapFunctional(c.default || c))
export const EventosList = () => import('../..\\components\\eventos\\EventosList.vue' /* webpackChunkName: "components/eventos-list" */).then(c => wrapFunctional(c.default || c))
export const HomeEmptySection = () => import('../..\\components\\home\\EmptySection.vue' /* webpackChunkName: "components/home-empty-section" */).then(c => wrapFunctional(c.default || c))
export const HomeEventos = () => import('../..\\components\\home\\Eventos.vue' /* webpackChunkName: "components/home-eventos" */).then(c => wrapFunctional(c.default || c))
export const HomeInicio = () => import('../..\\components\\home\\Inicio.vue' /* webpackChunkName: "components/home-inicio" */).then(c => wrapFunctional(c.default || c))
export const HomeMisCursos = () => import('../..\\components\\home\\MisCursos.vue' /* webpackChunkName: "components/home-mis-cursos" */).then(c => wrapFunctional(c.default || c))
export const HomeMisEventos = () => import('../..\\components\\home\\MisEventos.vue' /* webpackChunkName: "components/home-mis-eventos" */).then(c => wrapFunctional(c.default || c))
export const HomeMisProgramas = () => import('../..\\components\\home\\MisProgramas.vue' /* webpackChunkName: "components/home-mis-programas" */).then(c => wrapFunctional(c.default || c))
export const HomeNoticias = () => import('../..\\components\\home\\Noticias.vue' /* webpackChunkName: "components/home-noticias" */).then(c => wrapFunctional(c.default || c))
export const HomeProgramasCorfo = () => import('../..\\components\\home\\ProgramasCorfo.vue' /* webpackChunkName: "components/home-programas-corfo" */).then(c => wrapFunctional(c.default || c))
export const HomeProgramasSercotec = () => import('../..\\components\\home\\ProgramasSercotec.vue' /* webpackChunkName: "components/home-programas-sercotec" */).then(c => wrapFunctional(c.default || c))
export const NoticiasList = () => import('../..\\components\\noticias\\NoticiasList.vue' /* webpackChunkName: "components/noticias-list" */).then(c => wrapFunctional(c.default || c))
export const ProgramasList = () => import('../..\\components\\programas\\ProgramasList.vue' /* webpackChunkName: "components/programas-list" */).then(c => wrapFunctional(c.default || c))
export const EventosInscripcionConfirmarInscripcion = () => import('../..\\components\\eventos\\inscripcion\\ConfirmarInscripcion.vue' /* webpackChunkName: "components/eventos-inscripcion-confirmar-inscripcion" */).then(c => wrapFunctional(c.default || c))
export const EventosInscripcionForm = () => import('../..\\components\\eventos\\inscripcion\\InscripcionForm.vue' /* webpackChunkName: "components/eventos-inscripcion-form" */).then(c => wrapFunctional(c.default || c))
export const EventosInscripcionPublicEventoInscripcion = () => import('../..\\components\\eventos\\inscripcion\\PublicEventoInscripcion.vue' /* webpackChunkName: "components/eventos-inscripcion-public-evento-inscripcion" */).then(c => wrapFunctional(c.default || c))
export const EventosInscripcionUserLoggedForm = () => import('../..\\components\\eventos\\inscripcion\\UserLoggedForm.vue' /* webpackChunkName: "components/eventos-inscripcion-user-logged-form" */).then(c => wrapFunctional(c.default || c))
export const PaginasNosotrosListadoPaginas = () => import('../..\\components\\paginas\\nosotros\\NosotrosListadoPaginas.vue' /* webpackChunkName: "components/paginas-nosotros-listado-paginas" */).then(c => wrapFunctional(c.default || c))
export const PaginasServiciosListadoPaginas = () => import('../..\\components\\paginas\\servicios\\ServiciosListadoPaginas.vue' /* webpackChunkName: "components/paginas-servicios-listado-paginas" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
