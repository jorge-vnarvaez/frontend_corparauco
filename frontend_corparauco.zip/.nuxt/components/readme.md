# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<CentroDeMediosBarraOrganizadores>` | `<centro-de-medios-barra-organizadores>` (components/centro_de_medios/BarraOrganizadores.vue)
- `<CentroDeMediosCursos>` | `<centro-de-medios-cursos>` (components/centro_de_medios/Cursos.vue)
- `<CentroDeMediosCursosRecientes>` | `<centro-de-medios-cursos-recientes>` (components/centro_de_medios/CursosRecientes.vue)
- `<CentroDeMediosCursosRecomendados>` | `<centro-de-medios-cursos-recomendados>` (components/centro_de_medios/CursosRecomendados.vue)
- `<CentroDeMediosInicio>` | `<centro-de-medios-inicio>` (components/centro_de_medios/Inicio.vue)
- `<CentroDeMediosNuevosCursos>` | `<centro-de-medios-nuevos-cursos>` (components/centro_de_medios/NuevosCursos.vue)
- `<CentroDeMediosNuevosCursosComponent>` | `<centro-de-medios-nuevos-cursos-component>` (components/centro_de_medios/NuevosCursosComponent.vue)
- `<CentroDeMediosOrganizadoresRecomendados>` | `<centro-de-medios-organizadores-recomendados>` (components/centro_de_medios/OrganizadoresRecomendados.vue)
- `<EmprendedoresList>` | `<emprendedores-list>` (components/emprendedores/EmprendedoresList.vue)
- `<EventosList>` | `<eventos-list>` (components/eventos/EventosList.vue)
- `<HomeEmptySection>` | `<home-empty-section>` (components/home/EmptySection.vue)
- `<HomeEventos>` | `<home-eventos>` (components/home/Eventos.vue)
- `<HomeInicio>` | `<home-inicio>` (components/home/Inicio.vue)
- `<HomeMisCursos>` | `<home-mis-cursos>` (components/home/MisCursos.vue)
- `<HomeMisEventos>` | `<home-mis-eventos>` (components/home/MisEventos.vue)
- `<HomeMisProgramas>` | `<home-mis-programas>` (components/home/MisProgramas.vue)
- `<HomeNoticias>` | `<home-noticias>` (components/home/Noticias.vue)
- `<HomeProgramasCorfo>` | `<home-programas-corfo>` (components/home/ProgramasCorfo.vue)
- `<HomeProgramasSercotec>` | `<home-programas-sercotec>` (components/home/ProgramasSercotec.vue)
- `<NoticiasList>` | `<noticias-list>` (components/noticias/NoticiasList.vue)
- `<ProgramasList>` | `<programas-list>` (components/programas/ProgramasList.vue)
- `<EventosInscripcionConfirmarInscripcion>` | `<eventos-inscripcion-confirmar-inscripcion>` (components/eventos/inscripcion/ConfirmarInscripcion.vue)
- `<EventosInscripcionForm>` | `<eventos-inscripcion-form>` (components/eventos/inscripcion/InscripcionForm.vue)
- `<EventosInscripcionPublicEventoInscripcion>` | `<eventos-inscripcion-public-evento-inscripcion>` (components/eventos/inscripcion/PublicEventoInscripcion.vue)
- `<EventosInscripcionUserLoggedForm>` | `<eventos-inscripcion-user-logged-form>` (components/eventos/inscripcion/UserLoggedForm.vue)
- `<PaginasNosotrosListadoPaginas>` | `<paginas-nosotros-listado-paginas>` (components/paginas/nosotros/NosotrosListadoPaginas.vue)
- `<PaginasServiciosListadoPaginas>` | `<paginas-servicios-listado-paginas>` (components/paginas/servicios/ServiciosListadoPaginas.vue)
