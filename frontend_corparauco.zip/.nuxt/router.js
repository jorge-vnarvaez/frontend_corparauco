import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _542dd4a4 = () => interopDefault(import('..\\pages\\acerca.vue' /* webpackChunkName: "pages/acerca" */))
const _b1564948 = () => interopDefault(import('..\\pages\\centro_de_medios.vue' /* webpackChunkName: "pages/centro_de_medios" */))
const _4b810974 = () => interopDefault(import('..\\pages\\contacto.vue' /* webpackChunkName: "pages/contacto" */))
const _81af9a98 = () => interopDefault(import('..\\pages\\cursos\\index.vue' /* webpackChunkName: "pages/cursos/index" */))
const _079fcf88 = () => interopDefault(import('..\\pages\\emprendedores\\index.vue' /* webpackChunkName: "pages/emprendedores/index" */))
const _cad8826a = () => interopDefault(import('..\\pages\\eventos\\index.vue' /* webpackChunkName: "pages/eventos/index" */))
const _461b0f56 = () => interopDefault(import('..\\pages\\home.vue' /* webpackChunkName: "pages/home" */))
const _eabea4fc = () => interopDefault(import('..\\pages\\iniciar_sesion.vue' /* webpackChunkName: "pages/iniciar_sesion" */))
const _03577546 = () => interopDefault(import('..\\pages\\noticias\\index.vue' /* webpackChunkName: "pages/noticias/index" */))
const _eff08de2 = () => interopDefault(import('..\\pages\\organizadores.vue' /* webpackChunkName: "pages/organizadores" */))
const _310b8f5a = () => interopDefault(import('..\\pages\\programas\\index.vue' /* webpackChunkName: "pages/programas/index" */))
const _3d7bb92a = () => interopDefault(import('..\\pages\\registro.vue' /* webpackChunkName: "pages/registro" */))
const _2c0fffd0 = () => interopDefault(import('..\\pages\\registro_exitoso.vue' /* webpackChunkName: "pages/registro_exitoso" */))
const _6690d04e = () => interopDefault(import('..\\pages\\tematicas\\index.vue' /* webpackChunkName: "pages/tematicas/index" */))
const _4862cb8e = () => interopDefault(import('..\\pages\\emprendedores\\testimonios.vue' /* webpackChunkName: "pages/emprendedores/testimonios" */))
const _7291f730 = () => interopDefault(import('..\\pages\\nosotros\\directorio.vue' /* webpackChunkName: "pages/nosotros/directorio" */))
const _1f26e778 = () => interopDefault(import('..\\pages\\nosotros\\politica-de-calidad.vue' /* webpackChunkName: "pages/nosotros/politica-de-calidad" */))
const _39d9303e = () => interopDefault(import('..\\pages\\nosotros\\quienes-somos.vue' /* webpackChunkName: "pages/nosotros/quienes-somos" */))
const _0af98da4 = () => interopDefault(import('..\\pages\\nosotros\\vision-y-mision.vue' /* webpackChunkName: "pages/nosotros/vision-y-mision" */))
const _c0641c86 = () => interopDefault(import('..\\pages\\servicios\\agente-operador-corfo.vue' /* webpackChunkName: "pages/servicios/agente-operador-corfo" */))
const _359d4c70 = () => interopDefault(import('..\\pages\\servicios\\agente-operador-sercotec.vue' /* webpackChunkName: "pages/servicios/agente-operador-sercotec" */))
const _81d16374 = () => interopDefault(import('..\\pages\\usuario\\nueva-password.vue' /* webpackChunkName: "pages/usuario/nueva-password" */))
const _b9c3c3b4 = () => interopDefault(import('..\\pages\\usuario\\recuperar-password.vue' /* webpackChunkName: "pages/usuario/recuperar-password" */))
const _d4e40200 = () => interopDefault(import('..\\pages\\cursos\\organizador\\_id.vue' /* webpackChunkName: "pages/cursos/organizador/_id" */))
const _24814b21 = () => interopDefault(import('..\\pages\\emprendedores\\emprendedor\\_id.vue' /* webpackChunkName: "pages/emprendedores/emprendedor/_id" */))
const _d6695bc8 = () => interopDefault(import('..\\pages\\cursos\\_id.vue' /* webpackChunkName: "pages/cursos/_id" */))
const _bab6c37c = () => interopDefault(import('..\\pages\\emprendedores\\_slug\\index.vue' /* webpackChunkName: "pages/emprendedores/_slug/index" */))
const _5db6e4c2 = () => interopDefault(import('..\\pages\\eventos\\_slug\\index.vue' /* webpackChunkName: "pages/eventos/_slug/index" */))
const _535f5f28 = () => interopDefault(import('..\\pages\\nosotros\\_page.vue' /* webpackChunkName: "pages/nosotros/_page" */))
const _06c4b7d6 = () => interopDefault(import('..\\pages\\noticias\\_slug.vue' /* webpackChunkName: "pages/noticias/_slug" */))
const _3478d1ea = () => interopDefault(import('..\\pages\\programas\\_slug.vue' /* webpackChunkName: "pages/programas/_slug" */))
const _33262430 = () => interopDefault(import('..\\pages\\servicios\\_page.vue' /* webpackChunkName: "pages/servicios/_page" */))
const _82b71e18 = () => interopDefault(import('..\\pages\\usuario\\_perfil.vue' /* webpackChunkName: "pages/usuario/_perfil" */))
const _cd4f11d4 = () => interopDefault(import('..\\pages\\eventos\\_slug\\inscripcion.vue' /* webpackChunkName: "pages/eventos/_slug/inscripcion" */))
const _5cf7c22a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/acerca",
    component: _542dd4a4,
    name: "acerca"
  }, {
    path: "/centro_de_medios",
    component: _b1564948,
    name: "centro_de_medios"
  }, {
    path: "/contacto",
    component: _4b810974,
    name: "contacto"
  }, {
    path: "/cursos",
    component: _81af9a98,
    name: "cursos"
  }, {
    path: "/emprendedores",
    component: _079fcf88,
    name: "emprendedores"
  }, {
    path: "/eventos",
    component: _cad8826a,
    name: "eventos"
  }, {
    path: "/home",
    component: _461b0f56,
    name: "home"
  }, {
    path: "/iniciar_sesion",
    component: _eabea4fc,
    name: "iniciar_sesion"
  }, {
    path: "/noticias",
    component: _03577546,
    name: "noticias"
  }, {
    path: "/organizadores",
    component: _eff08de2,
    name: "organizadores"
  }, {
    path: "/programas",
    component: _310b8f5a,
    name: "programas"
  }, {
    path: "/registro",
    component: _3d7bb92a,
    name: "registro"
  }, {
    path: "/registro_exitoso",
    component: _2c0fffd0,
    name: "registro_exitoso"
  }, {
    path: "/tematicas",
    component: _6690d04e,
    name: "tematicas"
  }, {
    path: "/emprendedores/testimonios",
    component: _4862cb8e,
    name: "emprendedores-testimonios"
  }, {
    path: "/nosotros/directorio",
    component: _7291f730,
    name: "nosotros-directorio"
  }, {
    path: "/nosotros/politica-de-calidad",
    component: _1f26e778,
    name: "nosotros-politica-de-calidad"
  }, {
    path: "/nosotros/quienes-somos",
    component: _39d9303e,
    name: "nosotros-quienes-somos"
  }, {
    path: "/nosotros/vision-y-mision",
    component: _0af98da4,
    name: "nosotros-vision-y-mision"
  }, {
    path: "/servicios/agente-operador-corfo",
    component: _c0641c86,
    name: "servicios-agente-operador-corfo"
  }, {
    path: "/servicios/agente-operador-sercotec",
    component: _359d4c70,
    name: "servicios-agente-operador-sercotec"
  }, {
    path: "/usuario/nueva-password",
    component: _81d16374,
    name: "usuario-nueva-password"
  }, {
    path: "/usuario/recuperar-password",
    component: _b9c3c3b4,
    name: "usuario-recuperar-password"
  }, {
    path: "/cursos/organizador/:id?",
    component: _d4e40200,
    name: "cursos-organizador-id"
  }, {
    path: "/emprendedores/emprendedor/:id?",
    component: _24814b21,
    name: "emprendedores-emprendedor-id"
  }, {
    path: "/cursos/:id",
    component: _d6695bc8,
    name: "cursos-id"
  }, {
    path: "/emprendedores/:slug",
    component: _bab6c37c,
    name: "emprendedores-slug"
  }, {
    path: "/eventos/:slug",
    component: _5db6e4c2,
    name: "eventos-slug"
  }, {
    path: "/nosotros/:page?",
    component: _535f5f28,
    name: "nosotros-page"
  }, {
    path: "/noticias/:slug",
    component: _06c4b7d6,
    name: "noticias-slug"
  }, {
    path: "/programas/:slug",
    component: _3478d1ea,
    name: "programas-slug"
  }, {
    path: "/servicios/:page?",
    component: _33262430,
    name: "servicios-page"
  }, {
    path: "/usuario/:perfil?",
    component: _82b71e18,
    name: "usuario-perfil"
  }, {
    path: "/eventos/:slug/inscripcion",
    component: _cd4f11d4,
    name: "eventos-slug-inscripcion"
  }, {
    path: "/",
    component: _5cf7c22a,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
