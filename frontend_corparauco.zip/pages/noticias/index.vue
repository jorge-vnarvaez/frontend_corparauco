<template>
  <noticias-list />
</template>

<script>

export default {
  
};
</script>

<style>
</style>