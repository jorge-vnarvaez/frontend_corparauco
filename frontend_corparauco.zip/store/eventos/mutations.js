export default {
    setAllEventos(state, eventos) {
        state.eventos = eventos;
    },
    setEventosRecientes(state, eventos) {
        state.eventosRecientes = eventos;
    }
}