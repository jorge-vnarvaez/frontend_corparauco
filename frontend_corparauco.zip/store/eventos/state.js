export default () => ({
    namespaced: true,
    eventos: [],
    eventosRecientes: [],
});