export default () => ({
    noticias: []
});