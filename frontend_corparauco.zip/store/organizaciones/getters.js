export default {
    getOrganizaciones(state) {
        return state.organizaciones;
    }
}