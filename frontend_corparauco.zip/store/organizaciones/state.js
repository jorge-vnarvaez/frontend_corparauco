export default () => ({
    organizaciones: [],
});