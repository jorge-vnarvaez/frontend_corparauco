export default {
    getPagina(state) {
        return state.pagina;
    }
}