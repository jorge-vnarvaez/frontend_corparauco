export default () => ({
    paginaEmprendedores: {},
    paginaTestimonios: {},
});