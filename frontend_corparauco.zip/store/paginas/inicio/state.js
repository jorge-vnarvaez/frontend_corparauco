export default () => ({
    app_logo: '/uploads/logo_baja_resoucion_150ppi_h8rgl8wl_75262bb2af.png',
    app_name: null,
    app_subtitle: null,
    pagina: {}
});