export default {
    setProgramas(state, data) {

        state.programas = data;

    }
}